<?php

/*
    Plugin Name:  Metabox_pro
*/

require "inc/admin/admin.php";
require "inc/shortcode/shortcode.php";
require "inc/wp_codex/wp_codex.php";
