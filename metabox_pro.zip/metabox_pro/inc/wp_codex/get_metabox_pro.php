<?php

function metabox_pro_arr_func( $arr ) {

    $arr[] = array(
        "id" => "metabox_pro",
        "title" => "Metabox Pro",
        "post_type" => "metabox_pro",
        "fields" => array(

            array(
                "type" => "text",
                "id" => "metabox_pro_id",
                "name" => "metabox_pro_id",
                "title" => "Metabox Pro ID",
            ),
            array(
                "type" => "text",
                "id" => "metabox_pro_title",
                "name" => "metabox_pro_title",
                "title" => "Metabox Pro Title",
            ),
            array(
                "type" => "text",
                "id" => "metabox_pro_screen",
                "name" => "metabox_pro_screen",
                "title" => "Metabox Pro Screen",
            ),
            array(
                "type" => "text",
                "id" => "metabox_pro_context",
                "name" => "metabox_pro_context",
                "title" => "Metabox Pro Context",
            ),
            array(
                "type" => "text",
                "id" => "metabox_pro_priority",
                "name" => "metabox_pro_priority",
                "title" => "Metabox Pro Priority",
            ),

        )
    );

    $arr[] = array(
        "id" => "metabox_pro_fields",
        "title" => "Metabox Pro Fields",
        "post_type" => "metabox_pro",
        "fields" => array(

            array(
                "type" => "multi_metabox_pro_fields",
                "id" => "multi_metabox_pro_fields",
                "name" => "multi_metabox_pro_fields",
                "title" => "Metabox Pro Fields",
            ),

        )
    );

return $arr; } add_filter("metabox_pro_arr", "metabox_pro_arr_func");

// Create metboax by metabox pro custom post type
function metabox_pro_arr_custom_post_type_func( $metabox ) {

    // The Query
    $args = array(
        "post_type" => "metabox_pro",
        "post_status" => "publish",
        "posts_per_page" => -1,
        "numberposts" => -1,
        "fields" => "ids"
    );
    $metabox_pro_posts = get_posts( $args );

    if( is_array($metabox_pro_posts) && count($metabox_pro_posts) > 0 ) {
        foreach( $metabox_pro_posts as $post_ID ) {

            // $post_ID = $metabox_pro_query->post->ID;
            $metabox_pro_id = get_post_meta( $post_ID, "metabox_pro_id", true );
            $metabox_pro_title = get_post_meta( $post_ID, "metabox_pro_title", true );
            $metabox_pro_screen = get_post_meta( $post_ID, "metabox_pro_screen", true );
            $metabox_pro_context = get_post_meta( $post_ID, "metabox_pro_context", true );
            $metabox_pro_priority = get_post_meta( $post_ID, "metabox_pro_priority", true );

            $metabox[] = array(
                "id" => $metabox_pro_id,
                "title" => $metabox_pro_title,
                "post_type" => $metabox_pro_screen,
                "fields" => array(
                    
                    /*
                    array(
                        "type" => "text",
                        "id" => "metabox_pro_id",
                        "name" => "metabox_pro_id",
                        "title" => "Metabox Pro ID",
                    ),
                    array(
                        "type" => "text",
                        "id" => "metabox_pro_Title",
                        "name" => "metabox_pro_Title",
                        "title" => "Metabox Pro Title",
                    ),
                    array(
                        "type" => "text",
                        "id" => "metabox_pro_Screen",
                        "name" => "metabox_pro_Screen",
                        "title" => "Metabox Pro Screen",
                    ),
                    array(
                        "type" => "text",
                        "id" => "metabox_pro_Context",
                        "name" => "metabox_pro_Context",
                        "title" => "Metabox Pro Context",
                    ),
                    array(
                        "type" => "text",
                        "id" => "metabox_pro_Priority",
                        "name" => "metabox_pro_Priority",
                        "title" => "Metabox Pro Priority",
                    ),
                    */
        
                )
            );

        }
    }

return $metabox; } add_filter("metabox_pro_arr", "metabox_pro_arr_custom_post_type_func");