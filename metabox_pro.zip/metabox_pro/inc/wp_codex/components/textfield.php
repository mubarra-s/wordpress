<?php

function metabox_textfield_css() { ?>
    <style>
        .metabox_pro--field { display: grid; grid-template-columns: 1fr; grid-gap: 10px; align-items: center; margin: 0 auto 30px; }
    </style>
<?php } add_action("admin_head", "metabox_textfield_css");

// HTML Field
function metabox_pro_field_textfield( $field ) {
    if( $field["type"] == "text" ) {

        $value = get_post_meta( $field["post_id"], $field["name"], true );
        $value = (!empty($value)) ? $value : "";
        ?>

        <div class="metabox_pro--field">
            <label class="metabox_pro--field--label" for="<?php echo $field["id"]; ?>"><?php _e( $field["title"], 'metabox' ); ?></label>
            <input class="metabox_pro--field--component" type="text" id="<?php echo $field["id"]; ?>" name="<?php echo $field["name"]; ?>" value="<?php echo $value; ?>" />
        </div>

    <?php }
} add_action( "metabox_pro_field", "metabox_pro_field_textfield" );

// Save Field
function metabox_pro_save_field_textfield( $field ) {
    if( $field["type"] == "text" ) {

        update_post_meta( $field["post_id"], $field["name"], $field["value"] );

    }
} add_action( "metabox_pro_save", "metabox_pro_save_field_textfield" );
