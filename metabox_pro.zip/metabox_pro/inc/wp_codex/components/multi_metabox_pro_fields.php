<?php

function metabox_multi_metabox_pro_fields_css() { ?>
    <style>
        .metabox_pro--fields--add { width: 48px; height: 48px; background: #eee; font-size: 32px; line-height: 38px; text-align: center; border-radius: 10px; cursor: pointer; margin: auto; }
        .metabox_pro--fields { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; grid-gap: 30px; align-items: center; padding: 15px; border: 1px solid #ccc; margin: 0 auto 30px; }
        .metabox_pro--field { width: 100%; }
    </style>
<?php } add_action("admin_head", "metabox_multi_metabox_pro_fields_css");

function metabox_multi_metabox_pro_fields_js() { ?>
    <script>
        function add_multi_metabox_pro_fields( $this ) {
            var field_id = $this.data("field_id");
            var field_name = $this.data("field_name");

            var html = '';
            html += '<div class="metabox_pro--fields">';
                html += '<div class="metabox_pro--field">';
                    html += '<label class="metabox_pro--field--label"><?php _e( "Field Type", 'metabox' ); ?></label>';
                    html += '<input class="metabox_pro--field--component" type="text" name="'+field_name+'_type[]" value="" />';
                html += '</div>';
                html += '<div class="metabox_pro--field">';
                    html += '<label class="metabox_pro--field--label"><?php _e( "Field ID", 'metabox' ); ?></label>';
                    html += '<input class="metabox_pro--field--component" type="text" name="'+field_name+'_id[]" value="" />';
                html += '</div>';
                html += '<div class="metabox_pro--field">';
                    html += '<label class="metabox_pro--field--label"><?php _e( "Field Name", 'metabox' ); ?></label>';
                    html += '<input class="metabox_pro--field--component" type="text" name="'+field_name+'_name[]" value="" />';
                html += '</div>';
                html += '<div class="metabox_pro--field">';
                    html += '<label class="metabox_pro--field--label"><?php _e( "Field Title", 'metabox' ); ?></label>';
                    html += '<input class="metabox_pro--field--component" type="text" name="'+field_name+'_title[]" value="" />';
                html += '</div>';
            html += '</div>';

            $this.prev().append(html);
        }
    </script>
<?php } add_action("admin_footer", "metabox_multi_metabox_pro_fields_js");

// HTML Field
function metabox_pro_field_multi_metabox_pro_fields( $field ) {
    if( $field["type"] == "multi_metabox_pro_fields" ) {

        $value_type = get_post_meta( $field["post_id"], $field["name"]."_type", true );
        var_dump($value_type);
        // $value = (!empty($value)) ? $value : "";
        ?>

        <div id="multi_metabox_pro_fields" class="metabox_pro--multi_metabox_pro_fields">

            <?php /*
            <div class="metabox_pro--fields">
                <div class="metabox_pro--field">
                    <label class="metabox_pro--field--label"><?php _e( "Field Type", 'metabox' ); ?></label>
                    <input class="metabox_pro--field--component" type="text" name="<?php echo $field["name"]; ?>['type']" value="" />
                </div>
                <div class="metabox_pro--field">
                    <label class="metabox_pro--field--label"><?php _e( "Field ID", 'metabox' ); ?></label>
                    <input class="metabox_pro--field--component" type="text" name="<?php echo $field["name"]; ?>['id']" value="" />
                </div>
                <div class="metabox_pro--field">
                    <label class="metabox_pro--field--label"><?php _e( "Field Name", 'metabox' ); ?></label>
                    <input class="metabox_pro--field--component" type="text" name="<?php echo $field["name"]; ?>['name']" value="" />
                </div>
                <div class="metabox_pro--field">
                    <label class="metabox_pro--field--label"><?php _e( "Field Title", 'metabox' ); ?></label>
                    <input class="metabox_pro--field--component" type="text" name="<?php echo $field["name"]; ?>['title']" value="" />
                </div>
            </div>
            */ ?>

        </div>

        <div data-field_name="<?php echo $field["name"]; ?>" data-field_id="<?php echo $field["id"]; ?>" class="metabox_pro--fields--add" onclick="add_multi_metabox_pro_fields( jQuery(this) );">+</div>

    <?php }
} add_action( "metabox_pro_field", "metabox_pro_field_multi_metabox_pro_fields" );

// Save Field
function metabox_pro_save_field_multi_metabox_pro_fields( $field ) {
    if( $field["type"] == "multi_metabox_pro_fields" ) {

        update_post_meta( $field["post_id"], $field["name"]."_type", $field["value"] );
        update_post_meta( $field["post_id"], $field["name"]."_id", $field["value"] );
        update_post_meta( $field["post_id"], $field["name"]."_name", $field["value"] );
        update_post_meta( $field["post_id"], $field["name"]."_title", $field["value"] );

    }
} add_action( "metabox_pro_save", "metabox_pro_save_field_multi_metabox_pro_fields" );
